//
//  FirstViewController.swift
//  CSPC1519
//
//  Created by Brennan H Prasad on 2019-03-18.
//  Copyright © 2019 Brennan H Prasad. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {
    @IBOutlet weak var BirthDatePicker: UIDatePicker!
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var emailFirst: UITextField!
    
    @IBOutlet weak var emailConfirm: UITextField!
   
    override func viewDidLoad() {
        
         let defaults = UserDefaults.standard
        
        if(defaults.string(forKey: "email_preference")==nil)
        {
            emailFirst.text=""
        }
        else{
            emailFirst.text=defaults.string(forKey: "email_preference");
            emailConfirm.text=defaults.string(forKey: "email_preference");
        }
        
        if(defaults.string(forKey: "first_preference") == nil)
        {
            firstName.text=""
        }
        else{
            firstName.text=defaults.string(forKey: "first_preference");
         
        }
        
        if(defaults.string(forKey: "last_preference")==nil)
        {
            lastName.text=""
        }
        else{
            lastName.text=defaults.string(forKey: "last_preference");
      
        }
        super.viewDidLoad()
        let date = NSDate()
        BirthDatePicker.setDate(date as Date, animated: false)
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func SavePressed(_ sender: Any) {
        let date = BirthDatePicker.date
        var error=""
        if(firstName.text!.isEmpty)
        {
            error = error + "\nMissing First Name "
        }
        if(lastName.text!.isEmpty)
        {
            error = error + "\nMissing Last Name"
        }
        if(emailFirst.text!.isEmpty)
        {
            error = error + "\nMissing Email"
        }
        if(emailConfirm.text!.isEmpty)
        {
            error = error + "\nMissing Email Confirmation"
        }
        if(emailConfirm.text != emailFirst.text)
        {
            error = error + "\nEmails Do Not Match"
        }
        let dateOfBirth = BirthDatePicker.date
        let today = NSDate()
        
        let gregorian = NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)!
        
        let age = gregorian.components([.year], from: dateOfBirth, to: today as Date, options: [])
        
        if age.year! < 18 {
           error = error + "\nYou Must be Over 18"
        }
        
        
        
        
        if (error != "")
        { let message = error
        let alert = UIAlertController(
            title: "Fix The Following Errors",
            message: message,
            preferredStyle: .alert)
        let action = UIAlertAction(
            title: "back",
            style: .default,
            handler: nil)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
        }
        else{
            let defaults = UserDefaults.standard
            defaults.set(firstName.text, forKey: myKeys.keyFirstName)
               defaults.set(firstName.text, forKey: "first_preference")
            
              defaults.set(lastName.text, forKey: myKeys.keyLastName)
             defaults.set(lastName.text, forKey: "last_preference")
              defaults.set(emailConfirm.text, forKey: myKeys.keyEmail)
            defaults.set(emailConfirm.text, forKey: "email_preference")
              defaults.set(BirthDatePicker.date, forKey: myKeys.keyAge)
            
            //Fresh Prizes For New User
            let array = ["$100 to Charity!","$10", "$100", "Apple Air Pods", "Apple I Pad", "Toyota Rav 4 Vehivle", "Surpeme Merch","Apple Iphone X"]
            
            
            defaults.set(array, forKey: myKeys.myPrizes)

            
            let alert = UIAlertController(
                title: "Saved",
                message: "User Saved Successfully",
                preferredStyle: .alert)
            let action = UIAlertAction(
                title: "Done",
                style: .default,
                handler: nil)
            alert.addAction(action)
            present(alert, animated: true, completion: nil)
            
        }
        
    }
   
}


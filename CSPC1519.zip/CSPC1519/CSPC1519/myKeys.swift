//
//  myKeys.swift
//  CSPC1519
//
//  Created by Brennan H Prasad on 2019-03-18.
//  Copyright © 2019 Brennan H Prasad. All rights reserved.
//

import UIKit

struct myKeys {
    static let keyFirstName = "firstNameStringKey"
    static let keyLastName = "lastNameStringKey"
    static let keyEmail = "emailStringKey"
    static let keyAge = "ageStringKey"
     static let myPrizes = "myPrizeKey"
    
}

//
//  SecondViewController.swift
//  CSPC1519
//
//  Created by Brennan H Prasad on 2019-03-18.
//  Copyright © 2019 Brennan H Prasad. All rights reserved.
//

import UIKit


class SecondViewController: UIViewController ,
UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var tableView: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dwarves.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: simpleTableIdentifier)
        if (cell == nil) {
            cell = UITableViewCell(
                style: UITableViewCellStyle.default,
                reuseIdentifier: simpleTableIdentifier)
        }
        
        
   
       
        
        cell?.textLabel?.text = dwarves[indexPath.row]
        
        if(cell?.textLabel?.text?.contains("$"))!
        {
            let image = UIImage(named: "dollar2")
            cell?.imageView?.image = image
        }
        else if(cell?.textLabel?.text?.contains("Apple"))!
        {
            let image = UIImage(named: "apple")
            cell?.imageView?.image = image
        }
        else if(cell?.textLabel?.text?.contains("Merch"))!
        {
            let image = UIImage(named: "shirt2")
            cell?.imageView?.image = image
        }
        else if(cell?.textLabel?.text?.contains("Vehicle"))!
        {
            let image = UIImage(named: "keys")
            cell?.imageView?.image = image
        }
        else if(cell?.textLabel?.text?.contains("Rolex"))!
        {
            let image = UIImage(named: "watches-2")
            cell?.imageView?.image = image
        }
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let rowValue = dwarves[indexPath.row]
        let message = "Would You Like To Send Prize \(rowValue)"
       
        let controller2 = UIAlertController(title: "Are You Sure?",
                                            message: "You will be emailed within 48 hours with your prize details", preferredStyle: .alert)
        let action3 = UIAlertAction(title: "Not Yet",
                                    style: .default, handler: nil)
        let action4 = UIAlertAction(title: "confirm",
                                    style: .default, handler: {action in
                                        
                                        self.dwarves.remove(at: indexPath.row)
                                        let defaults = UserDefaults.standard
                                        defaults.set(self.dwarves, forKey: myKeys.myPrizes)
                                        tableView.reloadData()
                                        
                                        
                                        
                           //send Email to test email (only works on mobile)
                                        let request: NSMutableURLRequest = NSMutableURLRequest(url: NSURL(string: "https://api.mailgun.net/v3/sandboxf27019b31b33485aa625fe4d09bd80f4.mailgun.org/")! as URL)
                                        request.httpMethod = "POST"
                                        
                                        // Basic Authentication
                                        let username = "api"
                                        let password = "2de46d073585d3beb9df9def60a7fadd-2416cf28-4c168555"
                                        let loginString = NSString(format: "%@:%@", username, password)
                                        let loginData: NSData = loginString.data(using: String.Encoding.utf8.rawValue)! as NSData
                                        let base64LoginString = loginData.base64EncodedString(options: [])
                                        request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")
                                        
                                        let bodyStr = "from=Mailgun Sandbox <sandboxf27019b31b33485aa625fe4d09bd80f4.mailgun.org>&to=Receiver name <brox_8@hotmail.com>&subject=Test&text=thank you!"
                                        
                                        // appending the data
                                        request.httpBody = bodyStr.data(using: String.Encoding.utf8);
                                        
                                        let task = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
                                            // ... do other stuff here
                                        })
                                        
                                        task.resume()
                                        
        })
        
        controller2.addAction(action3)
        controller2.addAction(action4)
        let controller = UIAlertController(title: "Prize Selected",
                                           message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "Not Yet",
                                   style: .default, handler: nil)
        let action2 = UIAlertAction(title: "Yes, Send It",
                                    style: .default, handler: {action in
                             
                                        self.present(controller2, animated: true, completion: nil)
                                        
        })
        
    
        controller.addAction(action)
        controller.addAction(action2)
        present(controller, animated: true, completion: nil)
            }
   
        
    var dwarves: [String] = []
    let simpleTableIdentifier = "SimpleTableIdentifier"
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    override func viewWillAppear(_ animated: Bool) {
        self.tableView.reloadData()
        let defaults = UserDefaults.standard
        if let stringOne = defaults.string(forKey: "first_preference") {
            nameLabel.text = stringOne  // Some String Value
        }
        if let stringTwo = defaults.string(forKey: "last_preference") {
            nameLabel.text = nameLabel.text! + " " + stringTwo // Another String Value
        }
        
        
        if(defaults.bool(forKey: "send_preference") == true)
        {
            if let charity = defaults.string(forKey: "charity"){
                
                if(charity=="none")
                {
                    if let stringThree = defaults.string(forKey: "email_preference") {
                        emailLabel.text = "Prizes Sending To: " + stringThree // Another String Value
                    }
                }
                else{
                    
                    emailLabel.text = "Prizes Sending To: " + charity
                }
                
            }
        }
        else
        {
            if let stringThree = defaults.string(forKey: "email_preference") {
                emailLabel.text = "Prizes Sending To: " + stringThree // Another String Value
            }
            
        }
        
        
        if let myarray:[String] = defaults.stringArray(forKey: myKeys.myPrizes) {
            // Some String Value
            dwarves = myarray
            
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
      
        
        let defaults = UserDefaults.standard
        if let stringOne = defaults.string(forKey: "first_preference") {
            nameLabel.text = stringOne  // Some String Value
        }
        if let stringTwo = defaults.string(forKey: "last_preference") {
           nameLabel.text = nameLabel.text! + " " + stringTwo // Another String Value
        }
        
        
            if(defaults.bool(forKey: "send_preference") == true)
            {
        if let charity = defaults.string(forKey: "charity"){
            
            if(charity=="none")
            {
                if let stringThree = defaults.string(forKey: "email_preference") {
                    emailLabel.text = "Prizes Sending To: " + stringThree // Another String Value
                }
            }
            else{
                
                 emailLabel.text = "Prizes Sending To: " + charity
            }
            
        }
            }
        else
            {
                if let stringThree = defaults.string(forKey: "email_preference") {
                    emailLabel.text = "Prizes Sending To: " + stringThree // Another String Value
                }
                
        }
        
    
        if let myarray:[String] = defaults.stringArray(forKey: myKeys.myPrizes) {
            // Some String Value
            dwarves = myarray
            
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


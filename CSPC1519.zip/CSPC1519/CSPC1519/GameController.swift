//
//  GameController.swift
//  CSPC1519
//
//  Created by Brennan H Prasad on 2019-03-18.
//  Copyright © 2019 Brennan H Prasad. All rights reserved.
//

import UIKit
import AVFoundation
class GameController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource  {
   private var images:[UIImage]!
    private var prizeNames:[String]!
    var player: AVAudioPlayer?
    var dwarves: [String] = []
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 5
    }
    func playSound() {
        guard let url = Bundle.main.url(forResource: "69688_lukaso_slot2", withExtension: "wav") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            let player = try AVAudioPlayer(contentsOf: url)
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return images.count
    }
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let image = images[row]
        let imageView = UIImageView(image: image)
        return imageView
    }
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 64
    }
    

    @IBOutlet weak var picker: UIPickerView!
    @IBOutlet weak var winLabel: UILabel!
    
    override func viewWillAppear(_ animated: Bool) {
        let defaults = UserDefaults.standard
        if let myarray:[String] = defaults.stringArray(forKey: myKeys.myPrizes) {
            // Some String Value
            dwarves = myarray
            
        }
        images = [
            UIImage(named: "keys")!,
            UIImage(named: "shirt")!,
            UIImage(named: "watches-2")!,
            UIImage(named: "apple")!,
            UIImage(named: "dollar2")!,
            UIImage(named: "shirt2")!
        ]
        winLabel.text = " " // Note the space between the quotes
        arc4random_stir()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults = UserDefaults.standard
        if let myarray:[String] = defaults.stringArray(forKey: myKeys.myPrizes) {
            // Some String Value
            dwarves = myarray
            
        }
        images = [
            UIImage(named: "keys")!,
            UIImage(named: "shirt")!,
            UIImage(named: "role")!,
            UIImage(named: "apple")!,
            UIImage(named: "Dollarsign")!,
            UIImage(named: "shirt2")!
        ]
        prizeNames = [
        "Vehicle",
        "Clothing1",
        "Rolex",
        "Apple",
        "DollarSign",
        "Clothing2"
        
        
        ]
        winLabel.text = " " // Note the space between the quotes
        arc4random_stir()
        // Do any additional setup after loading the view.
    }
    @IBAction func spin(_ sender: Any) {
        let defaults = UserDefaults.standard
        var win = false
        var numInRow = -1
        var lastVal = -1
        
        for i in 0..<5 {
            let newValue = Int(arc4random_uniform(UInt32(images.count)))
            if newValue == lastVal {
                // numInRow++   *** NOTE THAT increment/decrement operators are deprecated in Swift 3
                numInRow += 1
                
            
            } else {
                numInRow = 1
            }
            lastVal = newValue
         
            picker.selectRow(newValue, inComponent: i, animated: true)
            picker.reloadComponent(i)
            
                let selectedValue = picker.selectedRow(inComponent: 2)
                let myName = prizeNames[selectedValue]
                if(myName == "Vehicle")
                {
                    if numInRow == 4  {
                        win = true
                        self.playSound()
                        let message = "WOW! Mazda 3 added to your Prize Box"
                        let alert = UIAlertController(title: "GRAND PRIZE!", message: message, preferredStyle: .alert)
                        let action = UIAlertAction(title: "Confirm", style: .default, handler: nil)
                        alert.addAction(action)
                        present(alert, animated: true, completion: nil)
                        
                        self.dwarves.append("Mazda 3 Vehicle")
                        defaults.set(self.dwarves, forKey: myKeys.myPrizes)
                    }
                }
                else if (myName == "Clothing1")
                {
                    if numInRow == 4  {
                        win = true
                        self.playSound()
                        let message = "Nike Merch added to your Prize Box"
                        let alert = UIAlertController(title: "Congrats!", message: message, preferredStyle: .alert)
                        let action = UIAlertAction(title: "Confirm", style: .default, handler: nil)
                        alert.addAction(action)
                        present(alert, animated: true, completion: nil)
                        
                        self.dwarves.append("Nike Merch")
                        defaults.set(self.dwarves, forKey: myKeys.myPrizes)
                    }
                        
                    else if numInRow == 5  {
                        win = true
                        self.playSound()
                        let message = "WOW! Supreme Merch added to your Prize Box"
                        let alert = UIAlertController(title: "Congrats!", message: message, preferredStyle: .alert)
                        let action = UIAlertAction(title: "Confirm", style: .default, handler: nil)
                        alert.addAction(action)
                        present(alert, animated: true, completion: nil)
                        
                        self.dwarves.append("Supreme Merch")
                        defaults.set(self.dwarves, forKey: myKeys.myPrizes)
                    }
                }
                else if (myName == "Rolex")
                {
                    if numInRow == 4  {
                        win = true
                        let message = "WOW Rolex added to your Prize Box"
                        let alert = UIAlertController(title: "Congrats!", message: message, preferredStyle: .alert)
                        let action = UIAlertAction(title: "Confirm", style: .default, handler: nil)
                        alert.addAction(action)
                        present(alert, animated: true, completion: nil)
                        
                        self.dwarves.append("Rolex Submariner")
                        defaults.set(self.dwarves, forKey: myKeys.myPrizes)
                    }
                }
                else if (myName == "Apple")
                {
                    if numInRow == 3  {
                        win = true
                        let message = "iPhone Case added to your Prize Box"
                        let alert = UIAlertController(title: "Congrats!", message: message, preferredStyle: .alert)
                        let action = UIAlertAction(title: "Confirm", style: .default, handler: nil)
                        alert.addAction(action)
                        present(alert, animated: true, completion: nil)
                        
                        self.dwarves.append("Apple iPhone case")
                        defaults.set(self.dwarves, forKey: myKeys.myPrizes)
                    }
                    else if numInRow == 4  {
                        win = true
                        self.playSound()
                        let message = "Air Pods added to your Prize Box"
                        let alert = UIAlertController(title: "Congrats!", message: message, preferredStyle: .alert)
                        let action = UIAlertAction(title: "Confirm", style: .default, handler: nil)
                        alert.addAction(action)
                        present(alert, animated: true, completion: nil)
                        
                        self.dwarves.append("Apple Air Pods")
                        defaults.set(self.dwarves, forKey: myKeys.myPrizes)
                        
                    }
                    else if numInRow == 5  {
                        win = true
                        self.playSound()
                        let message = "WOW! iPhone X added to your Prize Box"
                        let alert = UIAlertController(title: "Congrats!", message: message, preferredStyle: .alert)
                        let action = UIAlertAction(title: "Confirm", style: .default, handler: nil)
                        alert.addAction(action)
                        present(alert, animated: true, completion: nil)
                        
                        self.dwarves.append("Apple iPhone X")
                        defaults.set(self.dwarves, forKey: myKeys.myPrizes)
                    }
                }
                else if (myName == "DollarSign")
                {
                    if numInRow == 3  {
                        win = true
                        self.playSound()
                        let message = "$10 added to your Prize Box"
                        let alert = UIAlertController(title: "Congrats!", message: message, preferredStyle: .alert)
                        let action = UIAlertAction(title: "Confirm", style: .default, handler: nil)
                        alert.addAction(action)
                        present(alert, animated: true, completion: nil)
                        
                        self.dwarves.append("$10")
                        defaults.set(self.dwarves, forKey: myKeys.myPrizes)
                    }
                    else if numInRow == 4  {
                        win = true
                        self.playSound()
                        let message = "$100 added to your Prize Box"
                        let alert = UIAlertController(title: "Congrats!", message: message, preferredStyle: .alert)
                        let action = UIAlertAction(title: "Confirm", style: .default, handler: nil)
                        alert.addAction(action)
                        present(alert, animated: true, completion: nil)
                        
                        self.dwarves.append("$100")
                        defaults.set(self.dwarves, forKey: myKeys.myPrizes)
                        
                    }
                    else if numInRow == 5  {
                        win = true
                        self.playSound()
                        let message = "WOW! $1000 added to your Prize Box"
                        let alert = UIAlertController(title: "Congrats!", message: message, preferredStyle: .alert)
                        let action = UIAlertAction(title: "Confirm", style: .default, handler: nil)
                        alert.addAction(action)
                        present(alert, animated: true, completion: nil)
                        
                        self.dwarves.append("$100")
                        defaults.set(self.dwarves, forKey: myKeys.myPrizes)
                    }
                }
                else if (myName == "Clothing2")
                {
                    if numInRow == 4  {
                        win = true
                        self.playSound()
                        let message = "Nike Merch added to your Prize Box"
                        let alert = UIAlertController(title: "Congrats!", message: message, preferredStyle: .alert)
                        let action = UIAlertAction(title: "Confirm", style: .default, handler: nil)
                        alert.addAction(action)
                        present(alert, animated: true, completion: nil)
                        
                        self.dwarves.append("Nike Merch")
                        defaults.set(self.dwarves, forKey: myKeys.myPrizes)
                    }
                        
                    else if numInRow == 5  {
                        win = true
                        self.playSound()
                        let message = "WOW! Supreme Merch added to your Prize Box"
                        let alert = UIAlertController(title: "Congrats!", message: message, preferredStyle: .alert)
                        let action = UIAlertAction(title: "Confirm", style: .default, handler: nil)
                        alert.addAction(action)
                        present(alert, animated: true, completion: nil)
                        
                        self.dwarves.append("Supreme Merch")
                        defaults.set(self.dwarves, forKey: myKeys.myPrizes)
                    }
                }
                
            
            
           
        
        }
        winLabel.text = win ? "WINNER!" : " "  // Note the space between the quotes
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
